/**
 *
 * Tests in this package perform basic sanity checks on the provided classes. Use
 * them as an example for testing systems, as well as to make sure you didn't
 * create any problems when modifying the code.
 *
 */
package il.ac.bgu.cs.formalmethodsintro.base.sanity;
