package il.ac.bgu.cs.formalmethodsintro.base.exceptions;

public enum TransitionSystemPart {
    LABELING_FUNCTION, INITIAL_STATES, TRANSITIONS, ACTIONS, STATES, ATOMIC_PROPOSITIONS
}
