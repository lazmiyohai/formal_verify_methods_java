package il.ac.bgu.cs.formalmethodsintro.base.verification;

public interface VerificationResult<S> {
}
