package il.ac.bgu.cs.formalmethodsintro.base.verification;

public class VerificationSucceeded<S> implements VerificationResult<S> {
}
