package il.ac.bgu.cs.formalmethodsintro.base.verification;

public class VeficationSucceeded<S> implements VerificationResult<S> {
}
