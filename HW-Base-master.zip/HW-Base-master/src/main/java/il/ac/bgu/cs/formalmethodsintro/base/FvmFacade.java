package il.ac.bgu.cs.formalmethodsintro.base;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import il.ac.bgu.cs.formalmethodsintro.base.fairness.FairnessCondition;
import il.ac.bgu.cs.formalmethodsintro.base.verification.VerificationSucceeded;
import il.ac.bgu.cs.formalmethodsintro.base.verification.VerificationFailed;

import il.ac.bgu.cs.formalmethodsintro.base.automata.Automaton;
import il.ac.bgu.cs.formalmethodsintro.base.automata.MultiColorAutomaton;
import il.ac.bgu.cs.formalmethodsintro.base.channelsystem.ChannelSystem;
import il.ac.bgu.cs.formalmethodsintro.base.circuits.Circuit;
import il.ac.bgu.cs.formalmethodsintro.base.exceptions.StateNotFoundException;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.LTL;
import il.ac.bgu.cs.formalmethodsintro.base.programgraph.ActionDef;
import il.ac.bgu.cs.formalmethodsintro.base.programgraph.ConditionDef;
import il.ac.bgu.cs.formalmethodsintro.base.programgraph.ParserBasedActDef;
import il.ac.bgu.cs.formalmethodsintro.base.programgraph.ParserBasedCondDef;
import il.ac.bgu.cs.formalmethodsintro.base.programgraph.ProgramGraph;
import il.ac.bgu.cs.formalmethodsintro.base.transitionsystem.AlternatingSequence;
import il.ac.bgu.cs.formalmethodsintro.base.transitionsystem.TransitionSystem;
import il.ac.bgu.cs.formalmethodsintro.base.util.Pair;
import il.ac.bgu.cs.formalmethodsintro.base.verification.VerificationResult;

import java.util.Collections;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import il.ac.bgu.cs.formalmethodsintro.base.nanopromela.NanoPromelaFileReader;
import il.ac.bgu.cs.formalmethodsintro.base.nanopromela.NanoPromelaParser.StmtContext;
import il.ac.bgu.cs.formalmethodsintro.base.nanopromela.NanoPromelaParser.OptionContext;

import il.ac.bgu.cs.formalmethodsintro.base.channelsystem.ParserBasedInterleavingActDef;

import il.ac.bgu.cs.formalmethodsintro.base.exceptions.ActionNotFoundException;

import il.ac.bgu.cs.formalmethodsintro.base.programgraph.PGTransition;

import il.ac.bgu.cs.formalmethodsintro.base.transitionsystem.TSTransition;

import il.ac.bgu.cs.formalmethodsintro.base.util.Util;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.AP;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.And;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.LTL;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.Next;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.Not;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.TRUE;
import il.ac.bgu.cs.formalmethodsintro.base.ltl.Until;
/**
 * Interface for the entry point class to the HW in this class. Our
 * client/testing code interfaces with the student solutions through this
 * interface only. <br>
 * More about facade: {@linkplain //www.vincehuston.org/dp/facade.html}.
 */
public class FvmFacade {

    private static FvmFacade INSTANCE = null;

    /**
     *
     * @return an instance of this class.
     */
    public static FvmFacade get() {
        if (INSTANCE == null) {
            INSTANCE = new FvmFacade();
        }
        return INSTANCE;
    }

    /**
     * Checks whether a transition system is action deterministic. I.e., if for
     * any given p and ÃŽÂ± there exists only a single tuple (p,ÃŽÂ±,q) in Ã¢â€ â€™. Note
     * that this must be true even for non-reachable states.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @return {@code true} iff the action is deterministic.
     */
    public <S, A, P> boolean isActionDeterministic(TransitionSystem<S, A, P> ts) {
        boolean ans= false;
        if (ts.getInitialStates().size() > 1) {
            ans=false;
            return ans;
        }
        else if(ts.getInitialStates().size()==1)
        {
            //we check all the state and for all the state we check all the actions
            for(S state : ts.getStates()) {
                for(A action : ts.getActions()) {
                    //check if non- deterministic
                    if(post(ts, state, action).size() > 1)//if we can to arrive from the state to more 1 state
                    {
                        ans =false;
                        return ans;
                    }
                }
            }
        }
        ans =true;
        return ans;
    }

    /**
     * Checks whether an action is ap-deterministic (as defined in class), in
     * the context of a given {@link TransitionSystem}.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @return {@code true} iff the action is ap-deterministic.
     */
    public <S, A, P> boolean isAPDeterministic(TransitionSystem<S, A, P> ts) {
        Set<Set<P>> ThePowerOfAP=Util.powerSet(ts.getAtomicPropositions());//2^AP
        boolean ans=false;
        if(ts.getInitialStates().size()>1){
            return ans;
        }
        else if (ts.getInitialStates().size()==1)
        {
            //we iterate of all the states
            for(S state: ts.getStates())
            {
                Set<S> allThePostOfThisState=post(ts,state);
                //we iterate of all the sets of AP.
                //example: AP={a,b} ,the power= {{a},{b},{a,b},{}}.
                for (Set<P> setFromAP: ThePowerOfAP)
                {
                    Set<S> setWithEquelLabels=new HashSet<S>();
                    for(S state2: ts.getStates())
                    {
                        if(ts.getLabel(state2).equals(setFromAP))
                        {
                            setWithEquelLabels.add(state2);//we collect all the states with same label
                        }
                    }
                    int numberOfStateWithThisAPAndPost=0;
                    for(S state3: setWithEquelLabels)
                    {
                        if(allThePostOfThisState.contains(state3))
                        {
                            numberOfStateWithThisAPAndPost++;//if we have two post states with sane label
                        }

                        if(numberOfStateWithThisAPAndPost>1)
                        {
                            ans=false;
                            return ans;
                        }
                    }
                }
            }
        }
        ans =true;
        return ans;
    }

    /**
     * Checks whether an alternating sequence is an execution of a
     * {@link TransitionSystem}, as defined in class.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @param e The sequence that may or may not be an execution of {@code ts}.
     * @return {@code true} iff {@code e} is an execution of {@code ts}.
     */
    public <S, A, P> boolean isExecution(TransitionSystem<S, A, P> ts, AlternatingSequence<S, A> e) {
        return (isInitialExecutionFragment(ts, e) && (isMaximalExecutionFragment(ts, e)));
    }

    /**
     * Checks whether an alternating sequence is an execution fragment of a
     * {@link TransitionSystem}, as defined in class.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @param e The sequence that may or may not be an execution fragment of
     * {@code ts}.
     * @return {@code true} iff {@code e} is an execution fragment of
     * {@code ts}.
     */
    public <S, A, P> boolean isExecutionFragment(TransitionSystem<S, A, P> ts, AlternatingSequence<S, A> e) {
        boolean ans=true;
        //we get sequence of states and actions alternate.
        // example: <s1,a1,s2,a2,s1,a3,s4>

        AlternatingSequence<S, A> seqForIterate = e;
        S StateToGo;

        for(int i =seqForIterate.size(); seqForIterate.size() > 1;seqForIterate = seqForIterate.tail().tail())
        {
            //we check if the state in index i is state in the transition system
            S StateFrom = seqForIterate.head();
            if(!ts.getStates().contains(StateFrom)) {
                throw new StateNotFoundException(StateFrom);
            }
            //we check if the state in index i+2 is state in the transition system
            StateToGo = seqForIterate.tail().tail().head();
            if(!ts.getStates().contains(StateToGo)) {
                throw new StateNotFoundException(StateToGo);
            }
            //we check if the action in index i+1 is action in the transition system
            A action = seqForIterate.tail().head();
            if(!ts.getActions().contains(action)) {
                throw new ActionNotFoundException(action);
            }
            //we check if the transition (i,i+1,i+2) is transition in the transition system
            TSTransition tempTransition = new TSTransition(StateFrom,action,StateToGo);
            if (!ts.getTransitions().contains(tempTransition)){
                ans=false;
                return  ans;
            }
            // move to the state
            StateFrom = StateToGo;
            i--;
            i--;
            if(i==0)
            {
                return ans;
            }
        }
        return ans;
    }

    /**
     * Checks whether an alternating sequence is an initial execution fragment
     * of a {@link TransitionSystem}, as defined in class.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @param e The sequence that may or may not be an initial execution
     * fragment of {@code ts}.
     * @return {@code true} iff {@code e} is an execution fragment of
     * {@code ts}.
     */
    public <S, A, P> boolean isInitialExecutionFragment(TransitionSystem<S, A, P> ts, AlternatingSequence<S, A> e) {
        boolean ans;
        //we check if it is exe fragment and if the first state in the seq is initial
        ans =isExecutionFragment(ts, e) && ts.getInitialStates().contains(e.head());
        return ans;
    }

    /**
     * Checks whether an alternating sequence is a maximal execution fragment of
     * a {@link TransitionSystem}, as defined in class.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param <P> Type of atomic propositions.
     * @param ts The transition system being tested.
     * @param e The sequence that may or may not be a maximal execution fragment
     * of {@code ts}.
     * @return {@code true} iff {@code e} is a maximal fragment of {@code ts}.
     */
    public <S, A, P> boolean isMaximalExecutionFragment(TransitionSystem<S, A, P> ts, AlternatingSequence<S, A> e) {
        boolean ans;
        //we check if it is exe fragment and if the last state in the seq is final state
        ans =isExecutionFragment(ts, e) && isStateTerminal(ts, e.last());
        return ans;
    }

    /**
     * Checks whether a state in {@code ts} is terminal.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @param s The state being tested for terminality.
     * @return {@code true} iff state {@code s} is terminal in {@code ts}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S, A> boolean isStateTerminal(TransitionSystem<S, A, ?> ts, S s) {
        return (post(ts, s).size() == 0);
    }

    /**
     * @param <S> Type of states.
     * @param ts Transition system of {@code s}.
     * @param s A state in {@code ts}.
     * @return All the states in {@code Post(s)}, in the context of {@code ts}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S> Set<S> post(TransitionSystem<S, ?, ?> ts, S s) {
        Set<S> ans = new HashSet<S>();

        for(Object action : ts.getActions()){
            ans.addAll(post((TransitionSystem<S, Object, ?>)ts, s, action));
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param ts Transition system of {@code s}.
     * @param c States in {@code ts}.
     * @return All the states in {@code Post(s)} where {@code s} is a member of
     * {@code c}, in the context of {@code ts}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S> Set<S> post(TransitionSystem<S, ?, ?> ts, Set<S> c) {
        Set<S> ans = new HashSet<S>();

        for(S s : c){
            ans.addAll(post(ts, s));
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @param s A state in {@code ts}.
     * @param a An action.
     * @return All the states that {@code ts} might transition to from
     * {@code s}, when action {@code a} is selected.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S, A> Set<S> post(TransitionSystem<S, A, ?> ts, S s, A a) {

        if(!ts.getStates().contains(s)) {
            throw new StateNotFoundException(s);
        }

        Set<S> ans = new HashSet<S>();
        //we iterate of all the transitions
        for(TSTransition<S,A> transition : ts.getTransitions()){
            if(transition.getFrom().equals(s) )
            {
                if(transition.getAction().equals(a))
                {
                    //we add the state we arrive
                    ans.add(transition.getTo());
                }

            }
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @param c Set of states in {@code ts}.
     * @param a An action.
     * @return All the states that {@code ts} might transition to from any state
     * in {@code c}, when action {@code a} is selected.
     */
    public <S, A> Set<S> post(TransitionSystem<S, A, ?> ts, Set<S> c, A a) {
        Set<S> ans = new HashSet<S>();

        for(S s : c){
            ans.addAll(post(ts, s, a));
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param ts Transition system of {@code s}.
     * @param s A state in {@code ts}.
     * @return All the states in {@code Pre(s)}, in the context of {@code ts}.
     */
    public <S> Set<S> pre(TransitionSystem<S, ?, ?> ts, S s) {
        Set<S> ans = new HashSet<S>();
        for(Object a : ts.getActions()){
            ans.addAll(pre((TransitionSystem<S, Object, ?>)ts, s, a));
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param ts Transition system of {@code s}.
     * @param c States in {@code ts}.
     * @return All the states in {@code Pre(s)} where {@code s} is a member of
     * {@code c}, in the context of {@code ts}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S> Set<S> pre(TransitionSystem<S, ?, ?> ts, Set<S> c) {
        Set<S> ans = new HashSet<S>();

        for(S s : c){
            ans.addAll(pre(ts, s));
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @param s A state in {@code ts}.
     * @param a An action.
     * @return All the states that {@code ts} might transitioned from, when in
     * {@code s}, and the last action was {@code a}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S, A> Set<S> pre(TransitionSystem<S, A, ?> ts, S s, A a) {
        if(!ts.getStates().contains(s)) {
            throw new StateNotFoundException(s);
        }

        Set<S> ans = new HashSet<S>();
        //we iterate of all the transitions
        for(TSTransition<S,A> transition : ts.getTransitions()){
            if(transition.getTo().equals(s) )
            {
                if(transition.getAction().equals(a))
                {
                    //we add the state we come
                    ans.add(transition.getFrom());
                }

            }
        }
        return ans;
    }

    /**
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @param c Set of states in {@code ts}.
     * @param a An action.
     * @return All the states that {@code ts} might transitioned from, when in
     * any state in {@code c}, and the last action was {@code a}.
     * @throws StateNotFoundException if {@code s} is not a state of {@code ts}.
     */
    public <S, A> Set<S> pre(TransitionSystem<S, A, ?> ts, Set<S> c, A a) {
        Set<S> ans = new HashSet<S>();

        for(S s : c){
            ans.addAll(pre(ts, s, a));
        }
        return ans;
    }

    /**
     * Implements the {@code reach(TS)} function.
     *
     * @param <S> Type of states.
     * @param <A> Type of actions.
     * @param ts Transition system of {@code s}.
     * @return All states reachable in {@code ts}.
     */
    public <S, A> Set<S> reach(TransitionSystem<S, A, ?> ts) {
        Set<S> ans=new HashSet<S>();

        Set<S> initialStates= ts.getInitialStates();
        //firstable we add the initial states
        for(S s: initialStates)
        {
            ans.add(s);
        }

        for(S s : initialStates)
        {
            Set<S> post= post(ts,s); //we check all the states we can reach from initial states
            while(!post.isEmpty())
            {
                for(S s2: post)
                {

                    if(!ans.contains(s2))
                    {
                        ans.add(s2);
                    }
                }
                post=post(ts,post);
                for(Object s3 : post.toArray()) { /* Create a copy */

                    if(ans.contains(s3))
                    {
                        post.remove(s3); // if we was in the state we remove the state from the list
                    }
                }
            }
        }
        return ans;
    }

    /**
     * Compute the synchronous product of two transition systems.
     *
     * @param <S1> Type of states in the first system.
     * @param <S2> Type of states in the first system.
     * @param <A> Type of actions (in both systems).
     * @param <P> Type of atomic propositions (in both systems).
     * @param ts1 The first transition system.
     * @param ts2 The second transition system.
     *
     * @return A transition system that represents the product of the two.
     */
    public <S1, S2, A, P> TransitionSystem<Pair<S1, S2>, A, P> interleave(TransitionSystem<S1, A, P> ts1,
                                                                          TransitionSystem<S2, A, P> ts2) {
        TransitionSystem<Pair<S1,S2>, A, P> ret= new TransitionSystem<Pair<S1,S2>,A,P>();//ch create
        //we iterate of all the states in first system
        for(S1 s1 : ts1.getStates()) {
            //we iterate of all the states in second system
            for(S2 s2 : ts2.getStates()) {
                //we generate new state which include the two states
                Pair<S1, S2> newState = new Pair<>(s1, s2);
                ret.addState(newState);
                //if s1 is an initial state
                if (ts1.getInitialStates().contains(s1))
                    //we check if also s2 is an initial state
                    if (ts2.getInitialStates().contains(s2)) {
                        //add them as init states in the new interleave ts
                        ret.addInitialState(newState);
                    }
            }
        }
        //add A and AP of s1
        ret.addAllActions(ts1.getActions());
        ret.addAllAtomicPropositions(ts1.getAtomicPropositions());
        //add A and AP of s2
        ret.addAllActions(ts2.getActions());
        ret.addAllAtomicPropositions(ts2.getAtomicPropositions());

        Set<Pair<S1,S2>> statesList = ret.getStates();
        for(Pair<S1,S2> st : statesList) {
            Set<P> l1 = ts1.getLabel(st.first);
            Set<P> l2 = ts2.getLabel(st.second);
            for(P p1 : l1) {
                ret.addToLabel(st, p1);
            }
            for(P p2 : l2) {
                ret.addToLabel(st, p2);
            }
        }
        Set<TSTransition<S1,A>> tsList1 = ts1.getTransitions();
        Set<TSTransition<S2,A>> tsList2 = ts2.getTransitions();

        for(TSTransition<S1,A> trans1 : tsList1) {
            for(Pair<S1,S2> st : statesList) {
                //validate that we start with the first
                if(trans1.getFrom().equals(st.first)) {
                    Pair<S1,S2> sTo = new Pair<S1,S2>(trans1.getTo(), st.second);
                    A a = trans1.getAction();
                    TSTransition tst = new TSTransition<>(st, a, sTo);
                    ret.addTransition(tst);
                }
            }
        }

        for(TSTransition<S2,A> trans2 : tsList2) {
            for(Pair<S1,S2> st : statesList) {
                //validate that we start with the second
                if(trans2.getFrom().equals(st.second)) {
                    Pair<S1,S2> sTo = new Pair<S1,S2>(st.first, trans2.getTo());
                    A a = trans2.getAction();
                    ret.addTransition(new TSTransition<>(st, a, sTo));
                }
            }
        }
        //remove unreachable states and all the connections to those states
        return removeUnReachableStates(ret);
    }

    /**
     * Compute the synchronous product of two transition systems.
     *
     * @param <S1> Type of states in the first system.
     * @param <S2> Type of states in the first system.
     * @param <A> Type of actions (in both systems).
     * @param <P> Type of atomic propositions (in both systems).
     * @param ts1 The first transition system.
     * @param ts2 The second transition system.
     * @param handShakingActions Set of actions both systems perform together.
     *
     * @return A transition system that represents the product of the two.
     */
    public <S1, S2, A, P> TransitionSystem<Pair<S1, S2>, A, P> interleave(TransitionSystem<S1, A, P> ts1,
                                                                          TransitionSystem<S2, A, P> ts2, Set<A> handShakingActions) {
        TransitionSystem<Pair<S1, S2>, A, P> ret= new TransitionSystem<Pair<S1,S2>,A,P>();
        //interleave the both states
        Set<S1> stateList1 = ts1.getStates();
        Set<S2> stateList2 = ts2.getStates();
        for(S1 s1 : stateList1){
            for(S2 s2 : stateList2){
                Pair<S1,S2> newState=new Pair<S1,S2>(s1,s2);
                ret.addState(newState);
            }
        }
        //interleave the both initial states
        Set<S1> initList1 = ts1.getInitialStates();
        Set<S2> initList2 = ts2.getInitialStates();
        for (S1 s1 : initList1){
            for ( S2 s2 : initList2 ){
                Pair<S1,S2> newState=new Pair<S1,S2>(s1,s2);
                ret.addInitialState(newState);
            }
        }

        //interleave the actions of both ts
        Set<A> actList1 = ts1.getActions();
        Set<A> actList2 = ts2.getActions();
        for(A a: actList1)
            ret.addAction(a);
        for(A a: actList2)
            ret.addAction(a);

        //interleave the atomic propositions of both ts
        Set<P> apList1 = ts1.getAtomicPropositions();
        Set<P> apList2 = ts2.getAtomicPropositions();
        for(P ap : apList1)
            ret.addAtomicProposition(ap);
        for(P ap : apList2)
            ret.addAtomicProposition(ap);

        //interleave the labeles
        Set<Pair<S1,S2>> stateList = ret.getStates();
        for(Pair<S1,S2> s : stateList){
            Set<P> labels1 = ts1.getLabel(s.getFirst());
            Set<P> labels2 = ts2.getLabel(s.getSecond());
            for(P p: labels1)
                ret.addToLabel(s, p);
            for(P p: labels2)
                ret.addToLabel(s, p);
        }
        //interleave the transitins of both ts
        Set<TSTransition<S1, A>> trList1 = ts1.getTransitions();
        //we go over all the Actions in ts1
        for(TSTransition<S1,A> t1: trList1){
            A a = t1.getAction();
            Set<TSTransition<S2, A>> trList2 = ts2.getTransitions();
            //we go over all the actions on ts2 and find out the common action with ts1
            for(TSTransition<S2,A> t2: trList2){
                A a2 = t2.getAction();
                //if the action exists in both ts we add it to the interleave ts
                //if the Set of actions both systems perform together contains this action
                if( (a.equals(a2)) & (handShakingActions.contains(a)) ) {
                    Pair<S1,S2> from = new Pair<S1,S2>(t1.getFrom(),t2.getFrom());
                    Pair<S1,S2> to = new Pair<S1, S2>(t1.getTo(), t2.getTo());
                    TSTransition<Pair<S1, S2>, A> tstr = new TSTransition<Pair<S1, S2>, A>(from, a ,to);
                    ret.addTransition(tstr);
                }
                //if the Set of actions both systems perform together not contains a we change only the tranision from s2
                else if ( handShakingActions.contains(a)==false )
                {
                    for(S2 s2 : stateList2){
                        Pair<S1,S2> from = new Pair<S1,S2>(t1.getFrom(),s2);
                        Pair<S1,S2> to = new Pair<S1,S2>(t1.getTo(),s2);
                        TSTransition<Pair<S1, S2>, A> tstr = new TSTransition<Pair<S1,S2>,A>(from, a ,to);
                        ret.addTransition(tstr);
                    }
                }
            }


        }
        Set<TSTransition<S2, A>> trList2 = ts2.getTransitions();
        //we go over all the Actions in ts2
        for(TSTransition<S2,A> t2: trList2){
            A a2 = t2.getAction();
            //if the Set of actions both systems perform together not contains a2 we change only the tranision from s2
            if(handShakingActions.contains(a2) == false){
                for(S1 s1 : stateList1){
                    Pair<S1,S2> from = new Pair<S1,S2>(s1,t2.getFrom());
                    Pair<S1,S2> to = new Pair<S1,S2>(s1,t2.getTo());
                    TSTransition<Pair<S1, S2>, A> tstr = new TSTransition<Pair<S1,S2>,A>(from, a2, to);
                    ret.addTransition(tstr);
                }
            }
        }

        //remove unreachable states
        Set<Pair<S1, S2>> reachSt=reach(ret);
        Set<TSTransition<Pair<S1,S2>,A>> trList = ret.getTransitions();
        Set<P> apList = ret.getAtomicPropositions();
        for(Pair<S1,S2> s : stateList) {
            //if the state is reachable we do nothing
            if (reachSt.contains(s)) {
                return ret;
            }
            //case of unreachable states
            else {
                //remove all states that connected to them
                for (TSTransition<Pair<S1, S2>, A> tr : ret.getTransitions()) {
                    if (s.equals(tr.getFrom())) {
                        ret.removeTransition(tr);
                    }
                    if (s.equals(tr.getFrom())) {
                        ret.removeTransition(tr);
                    }
                }
                //remove all AP of the unreachable state
                for (P ap : apList) {
                    ret.removeLabel(s, ap);
                }
                //finally remove the unreachable state
                ret.removeState(s);
            }
        }
        return ret;
    }

    /**
     * Creates a new {@link ProgramGraph} object.
     *
     * @param <L> Type of locations in the graph.
     * @param <A> Type of actions of the graph.
     * @return A new program graph instance.
     */
    public <L, A> ProgramGraph<L, A> createProgramGraph() {
        return new ProgramGraph<L,A>();
    }

    /**
     * Interleaves two program graphs.
     *
     * @param <L1> Type of locations in the first graph.
     * @param <L2> Type of locations in the second graph.
     * @param <A> Type of actions in BOTH GRAPHS.
     * @param pg1 The first program graph.
     * @param pg2 The second program graph.
     * @return Interleaved program graph.
     */
    public <L1, L2, A> ProgramGraph<Pair<L1, L2>, A> interleave(ProgramGraph<L1, A> pg1, ProgramGraph<L2, A> pg2) {
        ProgramGraph<Pair<L1, L2>, A> PgToRet= new ProgramGraph<Pair<L1, L2>, A>();
        Pair<L1,L2> location;
        Pair<L1,L2> locs;
        //the locations
        Set<L1> locations1=pg1.getLocations(); //set of the locations of pg1
        for(L1 location1 : locations1){
            Set<L2> locations2=pg2.getLocations();//set of the locations of pg2
            for(L2 location2 : locations2){
                locs=new Pair<>(location1,location2);
                PgToRet.addLocation(locs);
            }
        }
        //the initial locations
        Set<L1> initLocs1=pg1.getInitialLocations();//set of the init locations of pg1
        for(L1 location1 : initLocs1){
            Set<L2> initLocs2=pg2.getInitialLocations();//set of the init locations of pg2
            for(L2 location2 : initLocs2){
                locs=new Pair<>(location1,location2);
                PgToRet.setInitial(locs, true);
            }
        }
        //initializations

        Set<List<String>> toInit1=pg1.getInitalizations();
        for(List<String> init: toInit1) {
            Set<List<String>> toInit2=pg2.getInitalizations();
            for(List<String> init2: toInit2){
                List<String> toAdd=new ArrayList<String>();
                toAdd.addAll(init);
                toAdd.addAll(init2);
                PgToRet.addInitalization(toAdd);// we add to initail states tje interleving inititial locs
            }
        }

        //the trans
        Set<PGTransition<L1, A>> transitions1=pg1.getTransitions();
        for(PGTransition<L1, A> t1: transitions1)//iterate on the transitions
        {
            Set<L2> locations2=pg2.getLocations();//set of the locations of pg2
            for(L2 l2: locations2){
                PgToRet.addTransition(new PGTransition<Pair<L1,L2>,A>(new Pair<L1,L2>(t1.getFrom(),l2),t1.getCondition(),t1.getAction(),new Pair<L1,L2>(t1.getTo(),l2)));
            }
        }
        Set<PGTransition<L2, A>> transitions2=pg2.getTransitions();
        for(PGTransition<L2, A> t2:transitions2) //iterate on the transitions
        {
            Set<L1> locations1new=pg1.getLocations(); //set of the locations of pg1
            for(L1 l1: locations1new){

                PgToRet.addTransition(new PGTransition<Pair<L1,L2>,A>(new Pair<L1,L2>(l1,t2.getFrom()),t2.getCondition(),t2.getAction(),new Pair<L1,L2>(l1,t2.getTo())));
            }
        }
        return PgToRet;
    }

    /**
     * Creates a {@link TransitionSystem} representing the passed circuit.
     *
     * @param c The circuit to translate into a {@link TransitionSystem}.
     * @return A {@link TransitionSystem} representing {@code c}.
     */
    public TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object> transitionSystemFromCircuit(
            Circuit c) {
        TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object> ret= new TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object>();
        Pair<Map<String, Boolean>,Map<String, Boolean>> newState;
        Set<String> inputs = c.getInputPortNames();
        Set<String> registers = c.getRegisterNames();
        Set<String> outputs = c.getOutputPortNames();
        //insert the names of the inputs,registers, outputs to the AP
        for(String input : inputs)
            ret.addAtomicProposition(input);
        for(String reg : registers)
            ret.addAtomicProposition(reg);
        for(String output : outputs)
            ret.addAtomicProposition(output);


        //we calculate the options of inputs in init states
        int numOfInputs=inputs.size();
        int numOfInitStates=(int)Math.pow(2, numOfInputs);
        Boolean[][] inputValues = new Boolean[numOfInitStates][numOfInputs];
        char[] binChar;
        Boolean[] boolValues;
        HashMap<String, Boolean> initInputs;
        Map<String, Boolean> initRegisters;
        Map<String, Boolean> compOuts;

        //for every state we need to calc the options
        for (int i = 0; i < numOfInitStates; i++) {

            //the value of regiaters in init states is false
            initRegisters = new HashMap<String,Boolean>();
            for(String reg : registers){
                initRegisters.put(reg, false);
            }

            //handle input initials values
            String binStr = Integer.toBinaryString(i);
            for (int binSize = binStr.length() ; binSize < numOfInputs; binSize = binStr.length())
                binStr = "0" + binStr;
            binChar = binStr.toCharArray();
            boolValues = new Boolean[numOfInputs];
            for (int j = 0; j < binChar.length; j++) {
                if(binChar[j] == '1'){
                    boolValues[j]=true;
                    inputValues[i][j]=true;
                }
                else if(binChar[j] == '0'){
                    boolValues[j]=false;
                    inputValues[i][j]=false;
                }
            }
            initInputs = new HashMap<String,Boolean>();
            init(initInputs, numOfInputs, inputs, boolValues, i);

            //generate the new state  - with the init values
            newState=new Pair<Map<String, Boolean>,Map<String, Boolean>>(initInputs,initRegisters);
            ret.addState(newState);
            ret.addInitialState(newState);

            //handle labels - add only those that have True value
            handleLabels(newState.getFirst(),newState,ret);
            handleLabels(newState.getSecond(),newState,ret);
            compOuts = c.computeOutputs(newState.first, newState.second);
            handleLabels(compOuts,newState,ret);

        }
        TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object> other= new TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object>();
        while(!ret.toString().equals(other.toString()))
        {
            for(Pair<Map<String, Boolean>, Map<String, Boolean>> p : ret.getInitialStates())
            {
                other.addInitialState(p);
            }
            for(Pair<Map<String, Boolean>, Map<String, Boolean>> p : ret.getStates())
            {
                other.addState(p);
            }
            for(Map<String, Boolean> p : ret.getActions())
            {
                other.addAction(p);
            }
            for(Object p : ret.getTransitions())
            {
                other.addTransition((TSTransition<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>>) p);
            }
            for(Object p : ret.getAtomicPropositions())
            {
                other.addAtomicPropositions(p);
            }

            //other=new TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object>(ans);
            Set<Pair<Map<String, Boolean>, Map<String, Boolean>>> otherStates = other.getStates();
            Pair<Map<String, Boolean>, Map<String, Boolean>> newState2;
            TSTransition<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>> newTs;
            Map<String, Boolean> outputsVal;
            HashMap<String,Boolean> initInputs2;

            for(Pair<Map<String, Boolean>, Map<String, Boolean>> state : otherStates)
            {
                for(int i=0; i<inputValues.length; i++)
                {
                    initInputs2=new HashMap<String,Boolean>();
                    init2(initInputs2, numOfInputs, inputs, inputValues, i);

                    //add the new action
                    if(!ret.getActions().contains(initInputs2)){
                        ret.addAction(initInputs2);
                    }

                    //add the new state
                    newState2 = new Pair<Map<String, Boolean>, Map<String, Boolean>>(initInputs2,c.updateRegisters(state.first, state.second));
                    if(!ret.getStates().contains(newState2)){
                        ret.addState(newState2);
                    }

                    //add the new transition
                    newTs = new TSTransition<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>>(state,initInputs2,newState2);
                    if(!ret.getTransitions().contains(newTs)){
                        ret.addTransition(newTs);
                    }

                    //handle labels - add only those that have True value
                    handleLabels(newState2.getFirst(),newState2,ret);
                    handleLabels(newState2.getSecond(),newState2,ret);
                    outputsVal = c.computeOutputs(newState2.first, newState2.second);
                    handleLabels(outputsVal,newState2,ret);

                }
            }
        }

        return ret;
    }

    /**
     * Creates a {@link TransitionSystem} from a program graph.
     *
     * @param <L> Type of program graph locations.
     * @param <A> Type of program graph actions.
     * @param pg The program graph to be translated into a transition system.
     * @param actionDefs Defines the effect of each action.
     * @param conditionDefs Defines the conditions (guards) of the program
     * graph.
     * @return A transition system representing {@code pg}.
     */
    public <L, A> TransitionSystem<Pair<L, Map<String, Object>>, A, String> transitionSystemFromProgramGraph(
            ProgramGraph<L, A> pg, Set<ActionDef> actionDefs, Set<ConditionDef> conditionDefs) {
        TransitionSystem<Pair<L, Map<String, Object>>, A, String> ans=new TransitionSystem<Pair<L, Map<String, Object>>, A, String>();
        int sizeOfinitPG=pg.getInitalizations().size();
        if(sizeOfinitPG<=0){
            Map<String,Object> map=new HashMap<String,Object>();
            addDetails(pg,ans,map);
        }
        else{
            Set<List<String>> init=pg.getInitalizations();
            for(List<String> lst : init)
            {
                Map<String,Object> map=new HashMap<String,Object>();

                for(String s: lst)
                {
                    map=ActionDef.effect(actionDefs, map, s);
                }
                addDetails(pg,ans,map);
            }
        }

        TransitionSystem<Pair<L, Map<String, Object>>, A, String> other = new TransitionSystem<Pair<L, Map<String, Object>>, A, String>();

        while(!ans.toString().equals(other.toString()))
        {
            //copy to temp transition system
            for(Pair<L, Map<String, Object>> p : ans.getInitialStates())
            {
                other.addInitialState(p);
            }
            for(Pair<L, Map<String, Object>> p : ans.getStates())
            {
                other.addState(p);
            }
            for(A p : ans.getActions())
            {
                other.addAction(p);
            }
            for(TSTransition<Pair<L, Map<String, Object>>, A> p : ans.getTransitions())
            {
                other.addTransition(p);
            }
            for(String p : ans.getAtomicPropositions())
            {
                other.addAtomicPropositions(p);
            }
            Set<Pair<L, Map<String, Object>>> pth=other.getStates();
            for(Pair<L, Map<String, Object>> p : pth)//iter over the states
            {
                for(PGTransition<L, A> pgt : pg.getTransitions())//iter over the trans of pg
                {
                    if((pgt.getFrom()!=null&&pgt.getFrom().equals(p.getFirst()))&&(ConditionDef.evaluate(conditionDefs, p.second, pgt.getCondition())))
                    {
                        //add new action
                        ans.addAction(pgt.getAction());
                        if(ActionDef.effect(actionDefs, p.second, pgt.getAction())!=null){
                            Pair<L, Map<String, Object>> StateToAdd = new Pair<L, Map<String, Object>>(pgt.getTo(),ActionDef.effect(actionDefs, p.second, pgt.getAction()));
                            //add new state
                            ans.addState(StateToAdd);
                            //add new transition
                            ans.addTransition(new TSTransition<Pair<L, Map<String, Object>>,A> (p,pgt.getAction(),StateToAdd));
                            //add atomic and labels
                            String AtomicToAdd=StateToAdd.first.toString();
                            ans.addAtomicProposition(AtomicToAdd);
                            ans.addToLabel(StateToAdd, AtomicToAdd);
                            Set<String> iter=StateToAdd.second.keySet();
                            for(String s : iter)
                            {

                                ans.addAtomicProposition(s+" = "+StateToAdd.second.get(s));
                                ans.addToLabel(StateToAdd, s+" = "+StateToAdd.second.get(s));
                            }
                        }
                    }
                }
            }
        }
        return ans;
    }






    /**
     * Creates a transition system representing channel system {@code cs}.
     *
     * @param <L> Type of locations in the channel system.
     * @param <A> Type of actions in the channel system.
     * @param cs The channel system to be translated into a transition system.
     * @return A transition system representing {@code cs}.
     */
    public <L, A> TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> transitionSystemFromChannelSystem(
            ChannelSystem<L, A> cs ) {

        Set<ActionDef> actions = Collections.singleton(new ParserBasedActDef());
        Set<ConditionDef> conditions = Collections.singleton(new ParserBasedCondDef());
        return transitionSystemFromChannelSystem(cs, actions, conditions);
    }

    public <L, A> TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> transitionSystemFromChannelSystem(
            ChannelSystem<L, A> cs, Set<ActionDef> actions, Set<ConditionDef> conditions) {

        ProgramGraph<List<L>, A> pg0 = PGOfLocsToPGOfListOfLocs(cs.getProgramGraphs().get(0));
        List<ProgramGraph<L, A>> pgList = cs.getProgramGraphs();
        int pgListSize = cs.getProgramGraphs().size();
        TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret=new TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String>();

        //add Actions to ret
        addAct( pgList, pgListSize, ret);

        //add locations to atomic propositions
        addLocs( pgList, pgListSize, ret);

        for(int i=1; i<pgListSize ;i++)
        {
            //init the pg
            ProgramGraph<List<L>, A> other = new ProgramGraph<List<L>, A>();
            //copy to temp programgraph
            for(List<L> p : pg0.getInitialLocations())
            {
                other.setInitial(p,true);
            }
            for(List<L> p : pg0.getLocations())
            {
                other.addLocation(p);
            }
            for(List<String> p : pg0.getInitalizations())
            {
                other.addInitalization(p);
            }
            pg0=new ProgramGraph<List<L>, A>();


            //add initial locations
            addInitLoc( pg0 , pgList, other, i);

            //add locations
            addLocation(pg0, pgList, other, i);

            //add initializations
            addInitialization(pg0, pgList, other, i);

            //add actions to ret from TS
            addActionsFromTs(pgList, i, ret);
        }

        //initial Parsers
        Set<ActionDef> actionDefs=new HashSet<ActionDef>();
        actionDefs.add(new ParserBasedInterleavingActDef());
        ParserBasedActDef actionParser = new ParserBasedActDef();
        actionDefs.add(actionParser);
        Set<ConditionDef> conditionDefs=new HashSet<ConditionDef>();
        ParserBasedCondDef conditionParser = new ParserBasedCondDef();
        conditionDefs.add(conditionParser);
        ParserBasedInterleavingActDef interParser= new ParserBasedInterleavingActDef();


        //---prepare ts from the pg--
        //handle initializations
        Set<List<String>> initialLs0 =  pg0.getInitalizations();
        Map<String,Object> vals;
        if(initialLs0.size() > 0){
            for(List<String> initial : initialLs0)
            {
                vals = new HashMap<String,Object>();
                for(String act : initial)
                {
                    vals=ActionDef.effect(actionDefs, vals, act);
                }
                handleinitLoc(vals, pg0, initialLs0,ret);
            }
        }
        else{
            handleinitLoc2(pg0, initialLs0,ret);
        }

        TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> tempPG = new TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String>();
        while(!ret.toString().equals(tempPG.toString()))
        {
            //copy to temp transition system
            for(Pair<List<L>, Map<String, Object>> p : ret.getInitialStates())
            {
                tempPG.addInitialState(p);
            }
            for(Pair<List<L>, Map<String, Object>> p : ret.getStates())
            {
                tempPG.addState(p);
            }
            for(A p : ret.getActions())
            {
                tempPG.addAction(p);
            }
            for(TSTransition<Pair<List<L>, Map<String, Object>>, A> p : ret.getTransitions())
            {
                tempPG.addTransition(p);
            }
            for(String p : ret.getAtomicPropositions())
            {
                tempPG.addAtomicPropositions(p);
            }
            //iterate over the states of temp
            Set<Pair<List<L>, Map<String, Object>>> StatesOfTemp= tempPG.getStates();
            for(Pair<List<L>, Map<String, Object>> p : StatesOfTemp)
            {
                int pSize = p.getFirst().size();
                for(int i=0;i< pSize ;i++){
                    L loc = p.getFirst().get(i);
                    ProgramGraph<L,A> ThisPG = pgList.get(i);
                    Set<PGTransition<L, A>> transOfThisPg =ThisPG.getTransitions();
                    //iterate of the transitions of this pg
                    for(PGTransition<L, A> trans : transOfThisPg){
                        if(CheckCond(conditionDefs,trans,loc,p)){
                            //we chceck the action of chsys
                            if(((String)trans.getAction()).contains("?")||((String)trans.getAction()).contains("!")){
                                //if not capacity
                                if(((String) trans.getAction()).substring(0,1).equals("_")){
                                    int Thesize=p.getFirst().size();
                                    for(int j=i+1;j < Thesize; j++){
                                        L loc2 = p.getFirst().get(j);
                                        boolean flag=false;
                                        ProgramGraph<L,A> ThisPG2 = pgList.get(j);
                                        Set<PGTransition<L, A>> transOfThisPg2 =ThisPG2.getTransitions();
                                        for(PGTransition<L, A> trans2 : transOfThisPg2){
                                            if(CheckCond(conditionDefs,trans2,loc2,p)){
                                                if(((String)trans.getAction()).contains("?")&&((String)trans2.getAction()).contains("!")){
                                                    int ind2=((String)trans2.getAction()).indexOf("!");
                                                    int ind1=((String)trans.getAction()).indexOf("?");
                                                    //same channel-///
                                                    if(((String)trans.getAction()).substring(0, ind1).equals(((String)trans2.getAction()).substring(0, ind2))){
                                                        flag=true;
                                                        AddAndCheck( trans, trans2, ret, i, j, p, interParser);
                                                    }
                                                }
                                                if(((String)trans.getAction()).contains("!")&&((String)trans2.getAction()).contains("?")){
                                                    flag=true;
                                                    int ind1=((String)trans.getAction()).indexOf("!");
                                                    int ind2=((String)trans2.getAction()).indexOf("?");
                                                    //same channel
                                                    if(((String)trans.getAction()).substring(0, ind1).equals(((String)trans2.getAction()).substring(0, ind2))){
                                                        AddAndCheck( trans, trans2, ret, i, j, p, interParser);
                                                    }
                                                }
                                            }
                                        }
                                        if(!flag){

                                            A a = trans.getAction();
                                            ret.addAction(a);
                                            try{
                                                handleNewAct (pSize, i, actionDefs, ret, trans, p);
                                            }
                                            catch(Exception e){}
                                        }
                                    }
                                }
                                else{
                                    A a = trans.getAction();
                                    ret.addAction(a);
                                    try {
                                        handleNewAct2(pSize, i, actionDefs, ret, trans, p);
                                    }
                                    catch(Exception e){}
                                }
                            }
                            else{
                                A a = trans.getAction();
                                ret.addAction(a);
                                try{
                                    handleNewAct(pSize, i, actionDefs, ret, trans, p);
                                }
                                catch(Exception e){}
                            }
                        }
                    }
                }
            }
        }
        //add locations as labels to the corresponding states
        Set<Pair<List<L>, Map<String, Object>>> stateList = ret.getStates();
        for(Pair<List<L>, Map<String, Object>> state : stateList){
            for(L loc : state.first){
                ret.addToLabel(state, loc+"");
            }
        }
        return ret;
    }


    /**
     * Construct a program graph from nanopromela code.
     *
     * @param filename The nanopromela code.
     * @return A program graph for the given code.
     * @throws Exception If the code is invalid.
     */
    public ProgramGraph<String, String> programGraphFromNanoPromela(String filename) throws Exception {
        return CreatePGFromContext(NanoPromelaFileReader.pareseNanoPromelaFile(filename));
    }

    /**
     * Construct a program graph from nanopromela code.
     *
     * @param nanopromela The nanopromela code.
     * @return A program graph for the given code.
     * @throws Exception If the code is invalid.
     */
    public ProgramGraph<String, String> programGraphFromNanoPromelaString(String nanopromela) throws Exception {
        return CreatePGFromContext(NanoPromelaFileReader.pareseNanoPromelaString(nanopromela));
    }

    /**
     * Construct a program graph from nanopromela code.
     *
     * @param inputStream The nanopromela code.
     * @return A program graph for the given code.
     * @throws Exception If the code is invalid.
     */
    public ProgramGraph<String, String> programGraphFromNanoPromela(InputStream inputStream) throws Exception {
        return CreatePGFromContext(NanoPromelaFileReader.parseNanoPromelaStream(inputStream));
    }
    /**
     * Creates a transition system from a transition system and an automaton.
     *
     * @param <Sts> Type of states in the transition system.
     * @param <Saut> Type of states in the automaton.
     * @param <A> Type of actions in the transition system.
     * @param <P> Type of atomic propositions in the transition system, which is
     * also the type of the automaton alphabet.
     * @param ts The transition system.
     * @param aut The automaton.
     * @return The product of {@code ts} with {@code aut}.
     */
    public <Sts, Saut, A, P> TransitionSystem<Pair<Sts, Saut>, A, Saut> product(TransitionSystem<Sts, A, P> ts,
                                                                                Automaton<Saut, P> aut) {
        Iterable<Saut> initialStatesAuto = aut.getInitialStates();//we get the initial states in the auotomat
        Set<Sts> initialStatesTS = ts.getInitialStates();//we get the initial states in the TS
        Queue<Pair<Sts, Saut>> Queuestates = new LinkedList<>();

        // in the transys we return the sts his pair<state in tssys,state in the auto>
        TransitionSystem<Pair<Sts, Saut>, A, Saut> TransitionSystemToReturn = new TransitionSystem<Pair<Sts, Saut>, A, Saut>();

        for (Sts iState : initialStatesTS)
        {
            Set<P> atomicPOfThisState = ts.getLabel(iState);
            for (Saut ai : initialStatesAuto)
            {
                Set<Saut> automatNextStates = aut.nextStates(ai, atomicPOfThisState);
                boolean empty=false;
                if(automatNextStates==null)
                {
                    empty=true;
                }
                else if(empty==false)
                {
                    TransitionSystemToReturn.addAllAtomicPropositions(automatNextStates);
                    for (Saut next_state : automatNextStates)
                    {
                        Pair<Sts, Saut> StateInit = new Pair(iState, next_state);
                        Queuestates.add(StateInit);
                        TransitionSystemToReturn.addState(StateInit);
                        TransitionSystemToReturn.addInitialState(StateInit);
                        TransitionSystemToReturn.addToLabel(StateInit, StateInit.second);
                    }
                }
            }
        }
        boolean QueueIsNotEmpty =!Queuestates.isEmpty();
        while (QueueIsNotEmpty)
        {
            Pair<Sts, Saut> StateWePoll = Queuestates.poll();
            Set<TSTransition<Sts, A>> ma = getTrans(StateWePoll, ts);
            for (TSTransition<Sts, A> t : ma)
            {
                Set<P> atomicPOfThisState = ts.getLabel(t.getTo());
                Set<Saut> automatNextStates = aut.nextStates(StateWePoll.getSecond(), atomicPOfThisState);
                boolean empty=false;
                if(automatNextStates==null)
                {
                    empty=true;
                }
                else if(empty==false)
                {
                    TransitionSystemToReturn.addAllAtomicPropositions(automatNextStates);
                    for (Saut state : automatNextStates)
                    {
                        Pair<Sts, Saut> TheNextState = new Pair<Sts, Saut>(t.getTo(), state);
                        Set <Pair<Sts, Saut>> TheStates = TransitionSystemToReturn.getStates();
                        boolean Contain=TheStates.contains(TheNextState);
                        if (Contain==false)
                        {
                            TransitionSystemToReturn.addState(TheNextState);
                            Queuestates.add(TheNextState);
                        }
                        TransitionSystemToReturn.addAction(t.getAction());
                        TransitionSystemToReturn.addTransition(new TSTransition<Pair<Sts, Saut>, A>(StateWePoll, t.getAction(), TheNextState));
                        TransitionSystemToReturn.addToLabel(TheNextState, TheNextState.second);
                    }
                }
            }
            QueueIsNotEmpty =!Queuestates.isEmpty();
        }
        return TransitionSystemToReturn;
    }

    /**
     * Verify that a system satisfies an omega regular property.
     *
     * @param <S> Type of states in the transition system.
     * @param <Saut> Type of states in the automaton.
     * @param <A> Type of actions in the transition system.
     * @param <P> Type of atomic propositions in the transition system, which is
     * also the type of the automaton alphabet.
     * @param ts The transition system.
     * @param aut A BÃƒÂ¼chi automaton for the words that do not satisfy the
     * property.
     * @return A VerificationSucceeded object or a VerificationFailed object
     * with a counterexample.
     */
    public <S, A, P, Saut> VerificationResult<S> verifyAnOmegaRegularProperty(TransitionSystem<S, A, P> ts,
                                                                              Automaton<Saut, P> aut) {

        Set<Pair<S, Saut>> s1 = new HashSet<Pair<S, Saut>>();
        Set<Pair<S, Saut>> s2 = new HashSet<Pair<S, Saut>>();
        Stack<Pair<S,Saut>> st1 = new Stack<Pair<S,Saut>>();
        Stack<Pair<S,Saut>> st2 = new Stack<Pair<S,Saut>>();

        Boolean IsReach = false;

        List<S> until = new ArrayList<S>();
        List <S> from = new ArrayList<S>();

        Queue<Pair<S, Saut>> QueueOfSatates = new LinkedList<Pair<S, Saut>>();
        //we get the Ts from the product function
        TransitionSystem<Pair<S, Saut>, A, Saut> TSFromP = product(ts, aut);
        QueueOfSatates.addAll(TSFromP.getInitialStates());

        for(;QueueOfSatates.size() > 0 && !IsReach;)
        {
            Pair<S, Saut> s = QueueOfSatates.poll();
            boolean contain =s2.contains(s);
            if (!contain)
            {
                IsReach = ifCycle_accStates(s,s2,st2,st1,s1,TSFromP,aut);
            }
        }

        if(IsReach)
        {
            VerificationFailed fa = new VerificationFailed();
            List<Pair<S,Saut>> listOfPair = new ArrayList<Pair<S,Saut>>();

            listOfPair.addAll(st2);
            listOfPair.addAll(st1);

            int length= listOfPair.size()-1;
            Pair<S,Saut> last = listOfPair.get(length);
            int indxOfLast = listOfPair.indexOf(last);

            List<Pair<S,Saut>> PairUntil = listOfPair.subList(0,indxOfLast);

            for(Pair<S,Saut> state : PairUntil)
            {
                until.add(state.first);
            }

            List<Pair<S,Saut>> PairFrom = listOfPair.subList(indxOfLast,listOfPair.size()-1);

            for(Pair<S,Saut> state : PairFrom)
            {
                from.add(state.first);
            }

            fa.setCycle(from);
            fa.setPrefix(until);
            return fa;

        }
        else
        {
            return new VerificationSucceeded<S>();
        }
    }

    /**
     * Translation of Linear Temporal Logic (LTL) formula to a Nondeterministic
     * BÃƒÂ¼chi Automaton (NBA).
     * @param <L> Type of resultant automaton transition alphabet
     * @param ltl The LTL formula represented as a parse-tree.
     * @return An automaton A such that L_\omega(A)=Words(ltl)
     */
    public <L> Automaton<?, L> LTL2NBA(LTL<L> ltl) {
        MultiColorAutomaton<Set<LTL<L>>, L> GNBA = new MultiColorAutomaton<>();

        //the algorithm we learn in the class:
        // (we take example the LTL - (a U b)- and run over it)
        //step 1: we generate the "sub" of the LTL - this is all the sub LTL and NOT them.
        // in our example: sub(a U b) = {{a,b,(aUb)},{!a,b,(aUb)},{a,!b,(aUb)},{!a,b,!(aUb)},{a,!b,!(aUb)},{a,b,!(aUb)},{!a,!b,!(aUb)},{!a,!b,(aUb)}}
        Queue<LTL<L>> theQueOfTheLTL = new ArrayDeque<>();
        theQueOfTheLTL.add(ltl);
        Set<LTL<L>> ltl_subs = new HashSet<>();

        while (!theQueOfTheLTL.isEmpty()) {
            LTL<L> ltl_poll = theQueOfTheLTL.poll();
            boolean contain =ltl_subs.contains(ltl_poll);
            if (!contain) {
                if (ltl_poll instanceof AP) {
                    ltl_subs.add(ltl_poll);
                }
                else if (ltl_poll instanceof And) {
                    ltl_subs.add(ltl_poll);
                    theQueOfTheLTL.add(((And<L>) ltl_poll).getRight());
                    theQueOfTheLTL.add(((And<L>) ltl_poll).getLeft());
                }
                else if (ltl_poll instanceof TRUE) {
                    ltl_subs.add(ltl_poll);
                }
                else if (ltl_poll instanceof Next) {
                    theQueOfTheLTL.add(((Next<L>) ltl_poll).getInner());
                    ltl_subs.add(ltl_poll);
                }
                else if (ltl_poll instanceof Until) {
                    ltl_subs.add(ltl_poll);
                    theQueOfTheLTL.add(((Until<L>) ltl_poll).getRight());
                    theQueOfTheLTL.add(((Until<L>) ltl_poll).getLeft());
                }
                else if (ltl_poll instanceof Not) {
                    theQueOfTheLTL.add(((Not<L>) ltl_poll).getInner());
                }

            }
        }
        //now we have in the set- {a,b,(aUb)}, we want to add the not of them and to partition to states with all the combinations.
        List<Set<LTL<L>>> AllSubs= allSubs(ltl_subs);
        //step 2: generate the closure
        //in our example the closure= {[a, b, (a U b)], [b, (a U b), !a], [a, !b, (a U b)] ,[a, !b, !(a U b)] ,[!b, !(a U b), !a]}
        List<Set<LTL<L>>> closure = new ArrayList<>();

        for (Set<LTL<L>> current_Sub : AllSubs) {
            boolean contain= current_Sub.contains(LTL.not(new TRUE<L>()));
            boolean legal = !contain;
            for (LTL<L> inner_Sub : current_Sub) {
                if (inner_Sub instanceof Until) legal &= withUntil(current_Sub, inner_Sub);

                if (inner_Sub instanceof And) {
                    legal &=  current_Sub.contains(((And<L>) inner_Sub).getLeft());
                    legal &=  current_Sub.contains(((And<L>) inner_Sub).getRight());
                }

                if (inner_Sub instanceof Not) {
                    LTL<L> exp = ((Not<L>) inner_Sub).getInner();
                    if (exp instanceof And) {
                        boolean legalAnd = current_Sub.contains(((And<L>) exp).getLeft());
                        legalAnd &= current_Sub.contains(((And<L>) exp).getRight());
                        legal &= !legalAnd;
                    }

                    if (exp instanceof Until) {
                        legal &= !current_Sub.contains(((Until<L>) exp).getRight());
                    }

                }
                if (!legal) break;
            }
            if (legal)
                closure.add(current_Sub);
        }
        //step 3: init initial stats:
        for(Set<LTL<L>> state : closure)
            GNBA.addState(state);

        Set<Set<LTL<L>>> init_st = closure.stream().filter(ltlSet -> ltlSet.contains(ltl)).collect(Collectors.toSet());
        for(Set<LTL<L>> initial_state : init_st)
            GNBA.setInitial(initial_state);
        //step 4: set accepts stats:
        Set<Next<L>> all_nexts =  ltl_subs.stream().filter(ltlExpr -> ltlExpr instanceof Next).map(ltl2 -> (Next<L>) ltl2).collect(Collectors.toSet());
        Set<Until<L>> all_untils =  ltl_subs.stream().filter(ltlExpr -> ltlExpr instanceof Until).map(ltl2 -> (Until<L>) ltl2).collect(Collectors.toSet());
        int color = 0;
        for (Until<L> until : all_untils) {
            Set<Set<LTL<L>>> StateOfCurrentVersion = closure.stream().filter(state -> !state.contains(until) || state.contains(until.getRight()))
                    .collect(Collectors.toSet());

            for(Set<LTL<L>> state : StateOfCurrentVersion)
            {
                GNBA.setAccepting(state,color);
            }
            color++;
        }
        //step 5: set transitions:
        for (Set<LTL<L>> fromState : closure) {
            Set<L> action = fromState.stream().filter(s -> s instanceof AP).map(s -> ((AP<L>)s).getName()).collect(Collectors.toSet());
            Set<Set<LTL<L>>> posts = closure.stream().filter(toState -> legal(fromState, toState, all_untils, all_nexts)).collect(Collectors.toSet());
            for(Set<LTL<L>> state : posts)
                GNBA.addTransition(fromState, action, state);
        }

        if(GNBA.getColors().size() == 0)
            for(Set<LTL<L>> state : closure)
                GNBA.setAccepting(state, 0);

        return GNBA2NBA(GNBA);
    }

    private  <L> boolean legal(Set<LTL<L>> fromState, Set<LTL<L>> toState, Set<Until<L>> allUntils, Set<Next<L>> allNexts) {
        if(!fNext(allNexts, toState, fromState) || !secUntil(allUntils, toState, fromState))
            return false;
        else
            return true;
    }

    private <L> boolean secUntil(Set<Until<L>> until_Exp, Set<LTL<L>> toState, Set<LTL<L>> fromState){
        for (Until<L> until_Exp_LTL : until_Exp) {
            boolean first_exp = fromState.contains(until_Exp_LTL);
            boolean second_exp = fromState.contains(until_Exp_LTL.getRight()) ||(fromState.contains(until_Exp_LTL.getLeft()) && toState.contains(until_Exp_LTL));
            if (!((!first_exp && !second_exp) || (first_exp && second_exp))) return false;
        }
        return true;
    }

    private <L> boolean fNext(Set<Next<L>> next_Expr, Set<LTL<L>> toState, Set<LTL<L>> fromState){
        for (Next<L> nxt_Exp_LTL : next_Expr) {
            boolean isFirst = fromState.contains(nxt_Exp_LTL);
            boolean isSecond = toState.contains(nxt_Exp_LTL.getInner());
            if (!((!isFirst && !isSecond) || (isFirst && isSecond))) return false;
        }
        return true;
    }

    private <L> boolean withUntil(Set<LTL<L>> currentSub, LTL<L> innerSub){
        boolean itIsLegal = currentSub.contains(((Until<L>) innerSub).getRight());
        itIsLegal |= currentSub.contains(((Until<L>) innerSub).getLeft());
        return itIsLegal;
    }

    private  <L> List<Set<LTL<L>>> allSubs(Set<LTL<L>> sub) {
        int the_pow = (int) Math.pow(2, sub.size());
        List<Set<LTL<L>>> subToReturn = new ArrayList<>(the_pow);//8
        //init
        for (int i = 0; i < the_pow; i++) {
            subToReturn.add(new HashSet<>(sub.size()));
        }
        int length_Of_Run=1;
        for (LTL<L> current : sub) {
            boolean flag = true; int counter = length_Of_Run;

            for (int j = 0; j < the_pow; j++) {
                if (flag)
                {subToReturn.get(j).add(current);}
                else
                {subToReturn.get(j).add(LTL.not(current));}

                counter--;
                if (counter == 0)
                {flag = !flag;
                    counter = length_Of_Run;}
            }
            length_Of_Run = length_Of_Run * 2;
        }
        return subToReturn;
    }

    /**
     * A translation of a Generalized BÃƒÂ¼chi Automaton (GNBA) to a
     * Nondeterministic BÃƒÂ¼chi Automaton (NBA).
     *
     * @param <L> Type of resultant automaton transition alphabet
     * @param mulAut An automaton with a set of accepting states (colors).
     * @return An equivalent automaton with a single set of accepting states.
     */
    public <L> Automaton<?, L> GNBA2NBA(MultiColorAutomaton<?, L> mulAut) {
        Automaton<Object, L> NBA = new Automaton<>();
        LinkedList<Integer> l = new LinkedList<>(mulAut.getColors());
        Collections.sort(l);

        Integer TheColor = l.getFirst();
        Queue<Pair<?, Integer>> states = new LinkedList<>();
        mulAut.getInitialStates().forEach(s0 -> {
            Pair<?, Integer> pair = new Pair<>(s0, TheColor);
            states.add(pair);
            NBA.setInitial(pair);
        });
        mulAut.getAcceptingStates(TheColor).forEach(s -> {
            NBA.setAccepting(new Pair<>(s, TheColor));
        });
        final Set<Pair<?, Integer>> isHave = new HashSet<>();

        while (!states.isEmpty()) {
            Pair<?, Integer> state = states.poll();
            isHave.add(state);
            Map<Set<L>, ? extends Set<?>> LTS = mulAut.getTransitions().get(state.first);
            for (Set<L> labelsSet : LTS.keySet()) {
                Integer indexOfTheColor = state.second;
                if (mulAut.getAcceptingStates(indexOfTheColor).contains(state.first)&& mulAut.getColors().size()>1)
                {
                    indexOfTheColor = ((indexOfTheColor+1) % (mulAut.getColors().size())+1) ;
                    indexOfTheColor--;
                }
                for (Object s : LTS.get(labelsSet)) {
                    Pair<?, Integer> pair = new Pair<>(s, indexOfTheColor);
                    NBA.addTransition(state, labelsSet, pair);
                    boolean contain =isHave.contains(pair);
                    if (!contain) {
                        states.add(pair);
                    }
                }
            }
        }
        return NBA;
    }



    /**
     * Verify that a system satisfies an LTL formula under fairness conditions.
     * @param ts Transition system
     * @param fc Fairness condition
     * @param ltl An LTL formula
     * @param <S>  Type of states in the transition system
     * @param <A> Type of actions in the transition system
     * @param <P> Type of atomic propositions in the transition system
     * @return a VerificationSucceeded object or a VerificationFailed object with a counterexample.
     */
    public <S, A, P> VerificationResult<S> verifyFairLTLFormula(TransitionSystem<S, A, P> ts, FairnessCondition<A> fc, LTL<P> ltl){
        TransitionSystem<Pair<S,A>, A, String> myts = new TransitionSystem<Pair<S,A>, A, String>();
        //handle ACT
        myts.addAllActions(ts.getActions());
        //handle AP
        ts.getAtomicPropositions().forEach(a ->{
            myts.addAtomicProposition(a.toString());
        });
        ts.getActions().forEach(act ->{
            myts.addAtomicProposition("t("+ act.toString()+")");
            myts.addAtomicProposition("e("+ act.toString()+")");
        });

        //handle initStates
        ts.getInitialStates().forEach(i ->{
            ts.getActions().forEach(act->{
                Pair<S,A> p = new  Pair<S,A>(i,act);
                myts.addInitialState(p);
                myts.addToLabel(p, "t("+ act.toString()+")");
                (ts.getLabel(i)).forEach(l->{
                    if(l.toString().length()!=0)
                        myts.addToLabel(p,l.toString());
                });
            });
        });

        //handle States
        Queue<Pair<S,A>> states = new LinkedList<>();
        Set<Pair<S,A>> discoveredstates = new HashSet<>();
        states.addAll(myts.getInitialStates());
        while (!states.isEmpty())
        {
            Pair<S,A> s = states.poll();
            discoveredstates.add(s);
            ts.getTransitions().forEach(tr->{
                if (tr.getFrom().equals(s.first)){
                    myts.addToLabel(s, "e("+ tr.getAction().toString()+")");
                    Pair<S,A> newS = new Pair<S,A>(tr.getTo(), tr.getAction());
                    myts.addState(newS);
                    myts.addToLabel(newS, "t("+ tr.getAction().toString()+")");
                    (ts.getLabel(tr.getTo())).forEach(l->{
                        if(l.toString().length()!=0)
                            myts.addToLabel(newS,l.toString());
                    });
                    myts.addTransitionFrom(s).action(tr.getAction()).to(newS);
                    if (!discoveredstates.contains(newS))
                    {
                        states.add(newS);
                    }
                }

            });
        }
        
        //for tests
        /*
        System.out.println("Initial");
        myts.getInitialStates().forEach(s -> {
            System.out.println(myts.getLabel(s));
            System.out.println(s);
        });

        System.out.println("trans");
        myts.getTransitions().forEach(tr -> {
            System.out.println(tr);
        });

        System.out.println("lables");
        myts.getTransitions().forEach(tr -> {
            System.out.println(tr.getTo()+ " lables: " +myts.getLabel(tr.getTo()));
        });
        */


        //handle unconditional fairness
        LTL<String> newLTL = LTL.true_();
        if(!fc.getUnconditional().isEmpty())
        {
            for (Set a:fc.getUnconditional() )
            {
                newLTL = LTL.and(newLTL, (always(eventually(or(a,"t")))));
            }
        }

        //handle strong fairness
        if(fc.getStrong().isEmpty())
            newLTL=LTL.and(newLTL,LTL.true_());
        else{
            for (Set a:fc.getStrong() )
            {
                newLTL = LTL.and(newLTL,imply(always(eventually(or(a, "e"))), always(eventually(or(a,"t")))));
            }
        }

        //handle weak fairness
        if(fc.getWeak().isEmpty())
            newLTL=LTL.and(newLTL,LTL.true_());
        else{
            for (Set a:fc.getWeak() )
            {
                newLTL = LTL.and(newLTL,imply(eventually(always(or(a, "e"))), always(eventually(or(a,"t")))));
            }
        }

        //ltl from P to String
        LTL ltl1 = ltl2Str(ltl);
        VerificationResult result = convertResult(verifyAnOmegaRegularProperty(myts,LTL2NBA(imply(newLTL,ltl1))));
        return result;

    }









    ////private functions/////////


    private <Sts, Saut, A, P> Set<TSTransition<Sts, A>> getTrans(Pair<Sts, Saut> firstPair, TransitionSystem<Sts, A, P> ts)
    {
        Set<TSTransition<Sts, A>> trs = ts.getTransitions();
        Set<TSTransition<Sts, A>> TSToReturn = trs.stream().filter(transition -> transition.getFrom().equals(firstPair.first)).collect(Collectors.toSet());

        return TSToReturn;
    }

    private <S, Saut> boolean ifCycle_accStates(Pair<S, Saut> s, Set<Pair<S, Saut>> s1, Stack<Pair<S, Saut>> st1, Stack<Pair<S, Saut>> st2, Set<Pair<S, Saut>> s2, TransitionSystem<Pair<S, Saut>, ?, Saut> tsP, Automaton<Saut, ?> aut)
    {
        Set<Saut> AccStates= aut.getAcceptingStates();
        boolean IfCycle = false;
        s1.add(s);
        st1.push(s);

        for(;!IfCycle && st1.size() > 0;)
        {
            Pair<S, Saut> StateInThePeek = st1.peek();
            Set<Pair<S,Saut>> PostStates = post(tsP,StateInThePeek);
            PostStates.removeAll(s1);
            if(PostStates.size() > 0)
            {
                Pair<S, Saut> tagS = (Pair<S, Saut>) PostStates.toArray()[0];
                s1.add(tagS);
                st1.push(tagS);
            }
            else
            {
                st1.pop();
                boolean contain =AccStates.contains(StateInThePeek.second);
                if(contain)
                {
                    IfCycle = if_have_cycle(StateInThePeek,tsP,st2,s2);
                }
            }
        }
        return IfCycle;
    }



    private <S, Saut> boolean if_have_cycle(Pair<S, Saut> s, TransitionSystem<Pair<S, Saut>, ?, ?> ts, Stack<Pair<S,Saut>> st1,Set<Pair<S,Saut>> s1)
    {
        boolean IfCycle = false;
        st1.add(s);
        s1.add(s);

        int SizeOfStack =st1.size();

        while(SizeOfStack > 0)
        {
            Pair<S,Saut> Stag = st1.peek();
            Set<Pair<S,Saut>> tagOfThePostOfState = post(ts,Stag);
            boolean contain =tagOfThePostOfState.contains(s);
            if(contain)
            {
                IfCycle = true;
                break;
            }
            else
            {
                tagOfThePostOfState.removeAll(s1);
                boolean isEnpty = tagOfThePostOfState.isEmpty();
                if(isEnpty)
                {
                    st1.pop();

                }
                else
                {
                    Pair<S, Saut> tagS = (Pair<S, Saut>) tagOfThePostOfState.toArray()[0];
                    st1.push(tagS);
                    s1.add(tagS);
                }
            }
            SizeOfStack =st1.size();
        }
        return  IfCycle;
    }



    private <L, A> void handleNewAct(int pSize, int i, Set<ActionDef> actionDefs, TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret,
                                     PGTransition<L, A> trans, Pair<List<L>, Map<String, Object>> p)
    {
        Map<String, Object> ef = ActionDef.effect(actionDefs, p.second,trans.getAction());
        if(ef !=null){
            List<L> newActTo = new ArrayList<L>();
            L l ;;
            for(int n=0; n< pSize ;n++){
                if(n==i) {
                    l = trans.getTo();
                    newActTo.add(l);
                }
                else
                {
                    l = p.getFirst().get(n);
                    newActTo.add(l);
                }
            }
            Pair<List<L>, Map<String, Object>> newState = new Pair<List<L>, Map<String, Object>>(newActTo,ActionDef.effect(actionDefs, p.second, (trans.getAction())));
            ret.addState(newState);
            TSTransition<Pair<List<L>, Map<String, Object>>,A> newts = new TSTransition<Pair<List<L>, Map<String, Object>>,A> (p,trans.getAction(),newState);
            ret.addTransition(newts);
            Set<String> vars = newState.second.keySet();
            //add the var names and values to AP and Labels
            for(String v : vars)
            {

                String sec = (String)newState.second.get(v);
                ret.addAtomicProposition(v+" = "+sec);
                ret.addToLabel(newState, v+" = "+sec);
            }
        }
    }


    private <L, A> void handleNewAct2(int pSize, int i, Set<ActionDef> actionDefs, TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret,
                                      PGTransition<L, A> trans, Pair<List<L>, Map<String, Object>> p) {
        Map<String, Object> ef = ActionDef.effect(actionDefs, p.second, trans.getAction());
        if (ef != null) {
            List<L> newActTo = new ArrayList<L>();
            for (int n = 0; n < pSize; n++) {
                L l;
                if (n == i) {
                    l = trans.getTo();
                    newActTo.add(l);
                } else {
                    l = p.getFirst().get(n);
                    newActTo.add(l);
                }
            }
            Pair<List<L>, Map<String, Object>> newState = new Pair<List<L>, Map<String, Object>>(newActTo, ActionDef.effect(actionDefs, p.second, trans.getAction()));
            ret.addState(newState);
            TSTransition<Pair<List<L>, Map<String, Object>>, A> newTS = new TSTransition<Pair<List<L>, Map<String, Object>>, A>(p, trans.getAction(), newState);
            ret.addTransition(newTS);
            Set<String> vars = newState.second.keySet();

            for (String v : vars) {
                ret.addAtomicProposition(v + " = " + newState.second.get(v));
                ret.addToLabel(newState, v + " = " + newState.second.get(v));

            }
        }
    }

    private <L,A> void addAct(List<ProgramGraph<L, A>> pgList, int pgListSize, TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret)
    {
        if(pgListSize > 0){
            Set<PGTransition<L, A>> tsList0 = pgList.get(0).getTransitions();
            for(PGTransition<L, A> ts : tsList0){
                A a = ts.getAction();
                ret.addAction(a);
            }
        }
    }

    private <L,A> void addLocs(List<ProgramGraph<L, A>> pgList, int pgListSize, TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret)
    {
        for(int i=0; i< pgListSize ;i++){
            Set<L> locList = pgList.get(i).getLocations();
            for(L loc : locList)
                ret.addAtomicProposition(loc+"");
        }
    }

    private <L,A> void addInitLoc(ProgramGraph<List<L>, A> pg0 , List<ProgramGraph<L, A>> pgList, ProgramGraph<List<L>, A> other, int i)
    {
        Set<L> initLocList = pgList.get(i).getInitialLocations();
        for(L loc : initLocList )
        {
            for(List<L> lst : other.getInitialLocations())
            {
                List<L> LocLst = new ArrayList<L>(lst);
                LocLst.add(loc);
                pg0.setInitial(LocLst, true);
            }
        }
    }

    private <L,A> void addLocation(ProgramGraph<List<L>, A> pg0 , List<ProgramGraph<L, A>> pgList, ProgramGraph<List<L>, A> other, int i)
    {
        Set<L> locList = pgList.get(i).getLocations();
        for(L loc : locList )
        {
            for(List<L> lst : other.getLocations())
            {
                List<L> LocLst = new ArrayList<L>(lst);
                LocLst.add(loc);
                pg0.addLocation(LocLst);
            }
        }
    }


    private <L,A> void addInitialization(ProgramGraph<List<L>, A> pg0 , List<ProgramGraph<L, A>> pgList, ProgramGraph<List<L>, A> other, int i)
    {
        Set<List<String>> initializationList =  pgList.get(i).getInitalizations();
        for(List<String> initLs : initializationList)
        {
            if(other.getInitalizations().size() > 0){
                for(List<String> lst1 : other.getInitalizations())
                {
                    List<String> init = initLs;
                    init.addAll(lst1);
                    pg0.addInitalization(init);
                }

            }
            else if (other.getInitalizations().size() == 0) {
                pg0.addInitalization(initLs);
            }
        }
    }

    private <L,A> void addActionsFromTs(List<ProgramGraph<L, A>> pgList, int i, TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String>ret)
    {
        Set<PGTransition<L, A>> tsList = pgList.get(i).getTransitions();
        for(PGTransition<L, A> ts : tsList){
            A a  = ts.getAction();
            ret.addAction(a);
        }
    }




    private <L,A> void handleinitLoc(Map<String,Object> vals, ProgramGraph<List<L>, A> pg0, Set<List<String>> initialLs0 , TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String>ret)
    {
        Pair<List<L>,Map<String,Object>> newState;
        Set<List<L>> initLocList0 = pg0.getInitialLocations();
        for(List<L> loc : initLocList0){
            newState = new Pair<List<L>,Map<String,Object>>(loc,vals);
            ret.addState(newState);
            ret.addInitialState(newState);
            Set<String> vars = newState.second.keySet();

            for(String v : vars)
            {
                ret.addAtomicProposition(v+" = "+newState.second.get(v));
                ret.addToLabel(newState, v+" = "+newState.second.get(v));
            }
        }
    }

    private <L,A> void handleinitLoc2(ProgramGraph<List<L>, A> pg0, Set<List<String>> initialLs0 , TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String>ret) {
        Map<String, Object> values = new HashMap<String, Object>();
        Set<List<L>> initLocList0 = pg0.getInitialLocations();
        Pair<List<L>, Map<String, Object>> newState;
        for (List<L> loc : initLocList0) {
            newState = new Pair<List<L>, Map<String, Object>>(loc, values);
            ret.addState(newState);
            ret.addInitialState(newState);
            Set<String> vars = newState.second.keySet();

            for (String v : vars) {
                String sec = (String) newState.second.get(v);
                ret.addAtomicProposition(v + " = " + sec);
                ret.addToLabel(newState, v + " = " + sec);
            }
        }
    }

    //handle labels - add only those that have True value
    private void handleLabels(Map<String, Boolean> map , Pair<Map<String, Boolean>, Map<String, Boolean>> state, TransitionSystem<Pair<Map<String, Boolean>, Map<String, Boolean>>, Map<String, Boolean>, Object> ret) {
        for(String input : map.keySet())
            if(map.get(input))
                ret.addToLabel(state, input);
    }

    private void init (HashMap<String,Boolean> map, int numOfInputs, Set<String> inputs, Boolean[] inputValues, int i)
    {
        int index=numOfInputs-1;
        for(String input : inputs) {
            map.put(input, inputValues[index]);
            index = index - 1;
        }
    }

    private void init2 (HashMap<String,Boolean> map, int numOfInputs, Set<String> inputs, Boolean[][] inputValues, int i){
        int index=numOfInputs-1;
        for(String input : inputs) {
            map.put(input, inputValues[i][index]);
            index = index - 1;
        }
    }


    private <L, A> TransitionSystem<Pair<L, Map<String, Object>>, A, String> addDetails( ProgramGraph<L, A> pg,TransitionSystem<Pair<L, Map<String, Object>>, A, String> transSys,Map<String,Object> map )
    {
        Set<L> initialLocations=pg.getInitialLocations();
        for(L l : initialLocations){
            Pair<L,Map<String,Object>> StateToAdd = new Pair<L,Map<String,Object>>(l,map);
            //add to states
            transSys.addState(StateToAdd);
            //add to initial states
            transSys.addInitialState(StateToAdd);
            Set<String> iter = StateToAdd.second.keySet();
            //add atomic and labels
            String AtomicToAdd=StateToAdd.first.toString();
            transSys.addAtomicProposition(AtomicToAdd);
            transSys.addToLabel(StateToAdd, AtomicToAdd);

            for(String s : iter)
            {
                //add to atomic propositions and to label the variables and their values
                transSys.addAtomicProposition(s+" = "+StateToAdd.second.get(s));
                transSys.addToLabel(StateToAdd, s+" = "+StateToAdd.second.get(s));
            }
        }
        return transSys;
    }



    private <L,A> ProgramGraph<List<L>,A> PGOfLocsToPGOfListOfLocs(ProgramGraph<L,A> pg)
    {
        ProgramGraph<List<L>,A> ans = new ProgramGraph<List<L>,A>();
        ans.setName(pg.getName());
//add locations
        for(L l : pg.getLocations()){
            List<L> locToAdd=new ArrayList<L>();
            locToAdd.add(l);
            ans.addLocation(locToAdd);
        }

//add initial locations
        for(L l:pg.getInitialLocations()){
            List<L> locToAdd=new ArrayList<L>();
            locToAdd.add(l);
            ans.setInitial(locToAdd, true);
        }
//add initializations
        for(List<String> lst : pg.getInitalizations()){
            ans.addInitalization(lst);
        }
//add transitions
        for(PGTransition<L,A> t:pg.getTransitions())
        {
            List<L> from=new ArrayList<L>();
            from.add(t.getFrom());
            List<L> to=new ArrayList<L>();
            to.add(t.getTo());
            PGTransition<List<L>,A> newTrans=new PGTransition<List<L>,A>(from,t.getCondition(),t.getAction(),to);
            ans.addTransition(newTrans);
        }
        return ans;

    }


    private ProgramGraph<String, String> CreatePGFromContext(StmtContext root) {

        Set<List<StmtContext>> TheStates = new HashSet<>();
        TheStates.add(Arrays.asList(root));

        Set<List<StmtContext>> read = new HashSet<>(TheStates);

        Set<MyInternalTransition> TheTrans = new HashSet<>();

        while (read.size()>0)
        {
            Set<List<StmtContext>> ThenewStates = new HashSet<>();
            for (List<StmtContext> list : read)
            {
                Set<MyInternalTransition> newtTrans = outgoingTransitionsFromStmtContexts(list);
                TheTrans.addAll(newtTrans);//here we add all the trans in the pg
                for (MyInternalTransition trans : newtTrans)
                {
                    if (!TheStates.contains(trans.getTo()))
                    {
                        TheStates.add(trans.getTo());
                        ThenewStates.add(trans.getTo());
                    }
                }
            }
            read = ThenewStates;
        }

        //initial the pg
        ProgramGraph<String, String> pg = (new FvmFacade()).createProgramGraph();

        //add location
        for (List<StmtContext> s : TheStates)
        {
            pg.addLocation(GetTheNameOfTheStateFromTheContext(s));
        }
        //add the initial location
        pg.setInitial(GetTheNameOfTheStateFromTheContext(Arrays.asList(root)), true);

//add all the transitions
        for (MyInternalTransition trans : TheTrans)
        {
            String from = GetTheNameOfTheStateFromTheContext(trans.getFrom());
            String to = GetTheNameOfTheStateFromTheContext(trans.getTo());
            pg.addTransition(new PGTransition<>(from, trans.getCond(), trans.getAct(), to));
        }
        return pg;

    }

    private static String GetTheNameOfTheStateFromTheContext(List<StmtContext> list) {
        String nameOfTheState = "";
        int i=0;
        boolean isTheFirstTime=true;
        for (StmtContext context : list)
        {
            if(i == 0 && isTheFirstTime)
            {
                nameOfTheState = nameOfTheState + context.getText();
                isTheFirstTime=false;
                i++;
            }
            else
            {
                nameOfTheState = nameOfTheState + ";" + context.getText();
                //we saprate with ";"
            }
        }
        return nameOfTheState;
    }

    private Set<MyInternalTransition> outgoingTransitionsFromStmtContexts(List<StmtContext> list) {

        //if the list is empty
        if (list.isEmpty()==true)
        {
            return new HashSet<>();
        }

        else
        {
            //if the list is not empty
            //if we have char,skip,ass,atomic statement
            if (list.get(0).assstmt() != null || list.get(0).chanreadstmt() != null || list.get(0).chanwritestmt() != null || list.get(0).atomicstmt() != null || list.get(0).skipstmt() != null)
            {
                List<StmtContext> MoveTo = new ArrayList<StmtContext>(list);
                MoveTo.remove(0);

                return new HashSet<MyInternalTransition>() {
                    {
                        add(new MyInternalTransition(list, "", list.get(0).getText(), MoveTo));
                    }
                };
            }
            else if (list.get(0).ifstmt() != null) { //if we have if statement
                Set<MyInternalTransition> AnsToRet = new HashSet<>();
                for (OptionContext opt : list.get(0).ifstmt().option())
                {
                    Set<MyInternalTransition> Optional = outgoingTransitionsFromStmtContexts(Arrays.asList(opt.stmt()));
                    for (MyInternalTransition trans : Optional)
                    {
                        String conditions = "(" + opt.boolexpr().getText() + ")" ;
                        conditions= conditions  + ((!trans.getCond().isEmpty()) ? " && (" + trans.getCond() + ")" : "");
                        List<StmtContext> joinedTo = new ArrayList<StmtContext>(trans.getTo());
                        joinedTo.addAll(list.subList(1, list.size()));
                        AnsToRet.add(new MyInternalTransition(list, conditions, trans.getAct(), joinedTo));
                    }
                }
                return AnsToRet;
            }
            else if (list.get(0).dostmt() != null) { //if we have do statement
                Set<MyInternalTransition> AnsToRet = new HashSet<>();
                for (OptionContext opt : list.get(0).dostmt().option())
                {
                    Set<MyInternalTransition> Optional = outgoingTransitionsFromStmtContexts(Arrays.asList(opt.stmt()));
                    for (MyInternalTransition trans : Optional)
                    {
                        String conditions = "(" + opt.boolexpr().getText() + ")" ;
                        conditions= conditions + ((!trans.getCond().isEmpty()) ? " && (" + trans.getCond() + ")" : "");
                        List<StmtContext> joinedTo = new ArrayList<>(trans.getTo());
                        joinedTo.addAll(list);
                        AnsToRet.add(new MyInternalTransition(list, conditions, trans.getAct(), joinedTo));
                    }
                }

                List<StmtContext> newLoc = new ArrayList<>(list);
                newLoc.remove(0);

                String allTheBoolExprs = "";
                String orLogic = "";

                for (OptionContext opt : list.get(0).dostmt().option())
                {
                    if (!opt.boolexpr().getText().isEmpty()) {
                        allTheBoolExprs =  allTheBoolExprs + (orLogic + "(" + opt.boolexpr().getText() + ")");
                        orLogic = "||";
                    }
                }
                AnsToRet.add(new MyInternalTransition(list, "!(" + allTheBoolExprs + ")", "", newLoc));

                return AnsToRet;
            }
            else
            {
                Set<MyInternalTransition> transitions = outgoingTransitionsFromStmtContexts(Arrays.asList(list.get(0).stmt(0)));
                Set<MyInternalTransition> AnsToRet = new HashSet<>();
                for (MyInternalTransition trans : transitions)
                {
                    List<StmtContext> newTo = new ArrayList<>(trans.getTo());
                    List<StmtContext> statement = list.get(0).stmt();
                    newTo.addAll(statement.subList(1, statement.size()));
                    AnsToRet.add(new MyInternalTransition(list, trans.getCond(), trans.getAct(), newTo));
                }
                return AnsToRet;
            }
        }
    }




    //remove unreachable states in the transition system and their AP
    private <STATE, ACTION, ATOMIC_PROPOSITION> TransitionSystem<STATE, ACTION, ATOMIC_PROPOSITION> removeUnReachableStates(TransitionSystem<STATE, ACTION, ATOMIC_PROPOSITION> ts) {

        Set<STATE> stateList = ts.getStates();
        Set<STATE> reachSt = reach(ts);
        Set<TSTransition<STATE, ACTION>> transSet = ts.getTransitions();
        Set<ATOMIC_PROPOSITION> apList = ts.getAtomicPropositions();
        //we iterate all over the states in the transition system and check if they are reachable
        for(STATE s : stateList) {
            //if the state is reachable we do nothing
            if(reachSt.contains(s)) {
                return ts;
            }
            //case of unreachable states
            else {
                //remove all states that connected to them
                for( TSTransition<STATE,ACTION> tr : transSet ){
                    if(s.equals(tr.getFrom())) {
                        ts.removeTransition(tr);
                    }
                    if(s.equals(tr.getFrom())) {
                        ts.removeTransition(tr);
                    }
                }
                //remove all AP of the unreachable state
                for(ATOMIC_PROPOSITION ap : apList){
                    ts.removeLabel(s, ap);
                }
                //finally remove the unreachable state
                ts.removeState(s);
            }
        }
        return ts;
    }
    /**
     *
     * @param <L> Type of locations in the channel system.
     * @param <A> Type of actions in the channel system.
     */
    private <L, A> Boolean CheckCond(Set<ConditionDef> CD,PGTransition<L, A> trans,L loc,Pair<List<L>, Map<String, Object>> s)
    {
        return (ConditionDef.evaluate(CD, s.second, trans.getCondition())&&trans.getFrom().equals(loc));
    }
    /**
     *
     * @param <L> Type of locations in the channel system.
     * @param <A> Type of actions in the channel system.
     */
    private <L, A> Boolean check(PGTransition<L, A> trans,PGTransition<L, A> trans2)
    {
        return ((String)trans.getAction()).contains("?")||((String)trans.getAction()).contains("!");
    }

    /**
     *
     * @param <L> Type of locations in the channel system.
     * @param <A> Type of actions in the channel system.
     *
     */
    private <L, A> void  AddAndCheck(PGTransition<L, A> trans,PGTransition<L, A> trans2,TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret,int i,int j,Pair<List<L>, Map<String, Object>> p,ParserBasedInterleavingActDef interParser)
    {

        A ActionToAdd = (A)(((String)trans.getAction())+ "|"+((String)trans2.getAction()));
//add new action
        ret.addAction(ActionToAdd);
        try{
            if(interParser.effect(p.second,ActionToAdd)!=null){
                List<L> newTo=new ArrayList<L>();
                for(int k=0 ; k<p.getFirst().size() ; k++){
                    if(k==i)
                        newTo.add(trans.getTo());
                    else{
                        if(k == j)
                            newTo.add(trans2.getTo());
                        else
                            newTo.add(p.getFirst().get(k));
                    }
                }
                Pair<List<L>, Map<String, Object>> StateToAdd = new Pair<List<L>, Map<String, Object>>(newTo,interParser.effect(p.second,ActionToAdd));
                //add new state
                ret.addState(StateToAdd);
                //add new transition
                ret.addTransition(new TSTransition<Pair<List<L>, Map<String, Object>>,A> (p,ActionToAdd,StateToAdd));
                AddIter(ret,StateToAdd);
            }
        }
        catch(Exception e){}
    }


    /**
     *
     * @param <L> Type of locations in the channel system.
     * @param <A> Type of actions in the channel system.
     */
    private <L, A> void AddIter(TransitionSystem<Pair<List<L>, Map<String, Object>>, A, String> ret,Pair<List<L>, Map<String, Object>> StateToAdd)
    {
        Set<String> iter=StateToAdd.second.keySet();
        for(String s : iter)
        {
            //add to atomic propositions and to label the variables and their values
            ret.addAtomicProposition(s+" = "+StateToAdd.second.get(s));
            ret.addToLabel(StateToAdd, s+" = "+StateToAdd.second.get(s));
        }
    }

    private <S,A> VerificationResult<S> convertResult(VerificationResult<Pair<S, A>> res) {
        if (res instanceof VerificationSucceeded)
            return new VerificationSucceeded();
        VerificationFailed<S> result = new VerificationFailed<S>();
        List<S> list1 = new LinkedList<S>();
        for (Pair<S, A> p : ((VerificationFailed<Pair<S, A>>) res).getCycle())
            list1.add(p.first);
        List<S> list2 = new LinkedList<S>();
        for (Pair<S, A> p : ((VerificationFailed<Pair<S, A>>) res).getPrefix())
            list1.add(p.first);
        result.setCycle(list1);
        result.setPrefix(list2);
        return result;
    }

    private <A> LTL or(Set<A> actions, String st)
    {
        LTL ltl = LTL.not(LTL.true_());
        for (A a: actions)
        {
            ltl = LTL.not(LTL.and(LTL.not(ltl),LTL.not(new AP(st+"("+a.toString()+")"))));
        }
        return ltl;
    }


    private <L> LTL<L> eventually(LTL<L> ltl) {
        return LTL.until(LTL.true_(), ltl);
    }

    private <L> LTL<L> always(LTL<L> ltl) {
        return LTL.not(eventually(LTL.not(ltl)));
    }

    private <L> LTL<L> imply(LTL<L> p, LTL<L> q) {
        return LTL.not(LTL.and(p, LTL.not(q)));
    }


    private <P> LTL<String> ltl2Str(LTL<P> ltl) {
        if (ltl instanceof Not) {
            Not<P> p = (Not<P>) ltl;
            return LTL.not(ltl2Str(p.getInner()));
        }
        if(ltl instanceof TRUE) {
            return new TRUE<String>();
        }
        if (ltl instanceof And) {
            And<P> p = (And<P>) ltl;
            LTL left = ltl2Str(p.getLeft());
            LTL right = ltl2Str(p.getRight());
            return LTL.and(left, right);
        }
        if (ltl instanceof Next) {
            Next<P> p = (Next<P>) ltl;
            return LTL.next(ltl2Str(p.getInner()));
        }
        if (ltl instanceof Until) {
            Until<P> p = (Until<P>) ltl;
            LTL left = ltl2Str(p.getLeft());
            LTL right = ltl2Str(p.getRight());
            return LTL.until(left, right);
        }
        return new AP<String>(ltl.toString());
    }



    class MyInternalTransition {
        private List<StmtContext> from;
        private List<StmtContext> to;
        private String cond;
        private String act;

        public MyInternalTransition(List<StmtContext> from, String cond, String act, List<StmtContext> to) {
            this.from = from;
            this.to = to;
            this.cond = cond;
            this.act = act;
        }

        public List<StmtContext> getFrom() {
            return from;
        }

        public void setFrom(List<StmtContext> from) {
            this.from = from;
        }

        public List<StmtContext> getTo() {
            return to;
        }

        public void setTo(List<StmtContext> to) {
            this.to = to;
        }

        public String getCond() {
            return cond;
        }

        public void setCond(String cond) {
            this.cond = cond;
        }

        public String getAct() {
            return act;
        }

        public void setAct(String act) {
            this.act = act;
        }

    }











}