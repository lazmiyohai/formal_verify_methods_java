#/bin/bash

java -cp ../../../../../../../lib/antlr-4.5.1-complete.jar org.antlr.v4.Tool -package il.ac.bgu.cs.formalmethodsintro.base.nanopromela NanoPromela.g4


